package com.cloudsense.markme;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import pl.pawelkleczkowski.customgauge.CustomGauge;

public class MainActivity extends AppCompatActivity {
    int progress=0;
    CountDownTimer timer;
    CustomGauge time;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        time=findViewById(R.id.gauge2);
        time.setValue(progress);

       /* Animation rotation = AnimationUtils.loadAnimation(this, R.anim.rotate);
        time.startAnimation(rotation);
        time.setValue(progress);*/
        timer=new CountDownTimer(5000,1) {
            @Override
            public void onTick(long millisUntilFinished) {
                Log.v("TIMER", "Tick of Progress"+ progress/50+"  " +millisUntilFinished);
                progress++;
               time.setValue((int)(5000-millisUntilFinished)/50);
            }

            @Override
            public void onFinish() {
                time.setValue(100);
            }
        };

        timer.start();
    }


}
