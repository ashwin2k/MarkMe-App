package com.cloudsense.markme;

public class Utility {
    public static long toMilli(int hour,int min)
    {
        long hr;
        long mn;
        hr=hour*60*60*1000;
        mn=min*60*1000;
        return hr+mn;
    }
}
